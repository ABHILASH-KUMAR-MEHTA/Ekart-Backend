package com.ekart.cart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
