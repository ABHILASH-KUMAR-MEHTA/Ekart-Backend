package com.ekart.cart.dto;

public enum Status {
    ADDED, ORDERED, DELIVERED, CANCELED
}
