package com.ekart.payment.dto;

public enum PaymentType {
    DEBIT_CARD, CREDIT_CARD, UPI
}
