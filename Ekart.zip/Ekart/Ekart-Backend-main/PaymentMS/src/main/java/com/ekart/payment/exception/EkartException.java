package com.ekart.payment.exception;

public class EkartException extends Exception {
    public EkartException(String message){
        super(message);
    }
}
