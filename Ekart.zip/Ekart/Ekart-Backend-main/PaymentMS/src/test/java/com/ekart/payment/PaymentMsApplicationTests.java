package com.ekart.payment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
