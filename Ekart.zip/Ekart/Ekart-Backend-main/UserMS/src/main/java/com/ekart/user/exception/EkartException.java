package com.ekart.user.exception;

public class EkartException extends Exception {
    public EkartException(String message){
        super(message);
    }
}
